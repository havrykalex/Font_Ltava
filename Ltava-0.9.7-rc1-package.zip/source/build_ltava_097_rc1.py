#!/usr/bin/env python3
"""Freeze the field-tested Ltava 0.9.7-alpha2 as Ltava 0.9.7-rc1."""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(PROJECT / "ltava_093/deps"))

from fontTools.pens.recordingPen import RecordingPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont


BASE = ROOT / "source/base"
ALPHA2_TTF = BASE / "Ltava-0.9.7-alpha2.ttf"
ALPHA2_OTF = BASE / "Ltava-0.9.7-alpha2.otf"
ALPHA2_WOFF2 = BASE / "Ltava-0.9.7-alpha2.woff2"
OUTPUT = ROOT / "output"
TTF = OUTPUT / "Ltava-0.9.7-rc1.ttf"
OTF = OUTPUT / "Ltava-0.9.7-rc1.otf"
WOFF2 = OUTPUT / "Ltava-0.9.7-rc1.woff2"
PROOF = OUTPUT / "Ltava-0.9.7-rc1-regression-proof.png"
VALIDATION = OUTPUT / "Ltava-0.9.7-rc1-VALIDATION.txt"
REPORT = OUTPUT / "Ltava-0.9.7-rc1-REPORT.txt"

FAMILY = "Ltava"
STYLE = "Regular"
FULL_NAME = "Ltava Regular"
PS_NAME = "Ltava-Regular"
VERSION_TEXT = "Version 0.907; Ltava 0.9.7-rc1"
UNIQUE_ID = "Ltava 0.9.7-rc1 Regular 2026"
AUTHOR = "Олександр Гаврик"

UI = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
UI_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
PAPER = (247, 244, 237)
INK = (25, 33, 39)
MUTED = (80, 96, 106)
BLUE = (43, 88, 116)
GREEN = (54, 108, 79)
RULE = (199, 191, 178)


def set_release_names(font: TTFont) -> None:
    """Keep Latin menu names and record the author's exact Ukrainian name."""
    name = font["name"]
    menu_values = {
        1: FAMILY,
        2: STYLE,
        3: UNIQUE_ID,
        4: FULL_NAME,
        5: VERSION_TEXT,
        6: PS_NAME,
        16: FAMILY,
        17: STYLE,
    }
    metadata_values = {**menu_values, 9: AUTHOR}
    name.names = [
        record
        for record in name.names
        if record.nameID not in metadata_values and record.platformID != 1
    ]
    for language_id in (0x0409, 0x0422):
        for name_id, value in metadata_values.items():
            name.setName(value, name_id, 3, 1, language_id)


def build_font(source: Path, destination: Path) -> None:
    font = TTFont(source, recalcBBoxes=False, recalcTimestamp=False)
    set_release_names(font)
    font["head"].fontRevision = 0.907
    if "CFF " in font:
        cff = font["CFF "].cff
        cff.fontNames = [PS_NAME]
        top = cff.topDictIndex[0]
        top.FullName = FULL_NAME
        top.FamilyName = FAMILY
        top.version = "0.907"
    font.save(destination, reorderTables=False)
    font.close()


def build_woff2() -> None:
    font = TTFont(TTF, recalcBBoxes=False, recalcTimestamp=False)
    font.flavor = "woff2"
    font.save(WOFF2, reorderTables=False)
    font.close()


def glyph_digest(font: TTFont) -> str:
    digest = hashlib.sha256()
    glyph_set = font.getGlyphSet()
    for name in font.getGlyphOrder():
        pen = RecordingPen()
        glyph_set[name].draw(pen)
        digest.update(name.encode())
        digest.update(repr(pen.value).encode())
    return digest.hexdigest()


def table_digest(font: TTFont, tag: str) -> str:
    return hashlib.sha256(font.getTableData(tag)).hexdigest()


def face(path: Path | str, size: int):
    return ImageFont.truetype(str(path), size, layout_engine=ImageFont.Layout.RAQM)


def pair_delta(font: ImageFont.FreeTypeFont, pair: str) -> float:
    return font.getlength(pair, features=["kern"]) - sum(
        font.getlength(character, features=["-kern"]) for character in pair
    )


def validate_freeze() -> list[str]:
    alpha_ttf = TTFont(ALPHA2_TTF, recalcBBoxes=False, recalcTimestamp=False)
    alpha_otf = TTFont(ALPHA2_OTF, recalcBBoxes=False, recalcTimestamp=False)
    alpha_web = TTFont(ALPHA2_WOFF2, recalcBBoxes=False, recalcTimestamp=False)
    ttf = TTFont(TTF, recalcBBoxes=False, recalcTimestamp=False)
    otf = TTFont(OTF, recalcBBoxes=False, recalcTimestamp=False)
    web = TTFont(WOFF2, recalcBBoxes=False, recalcTimestamp=False)
    checks: list[str] = []

    for source, candidate, label in (
        (alpha_ttf, ttf, "TTF"),
        (alpha_otf, otf, "OTF"),
        (alpha_web, web, "WOFF2"),
    ):
        if source.getGlyphOrder() != candidate.getGlyphOrder():
            raise RuntimeError(f"{label}: glyph order changed")
        if glyph_digest(source) != glyph_digest(candidate):
            raise RuntimeError(f"{label}: outlines changed")
        if source["hmtx"].metrics != candidate["hmtx"].metrics:
            raise RuntimeError(f"{label}: advances or sidebearings changed")
        for tag in ("cmap", "GPOS", "GSUB", "GDEF"):
            if table_digest(source, tag) != table_digest(candidate, tag):
                raise RuntimeError(f"{label}: {tag} changed")
        checks.append(f"{label}: alpha2 outlines, metrics, cmap, GPOS, GSUB and GDEF frozen")

    if len(ttf.getGlyphOrder()) != 220 or len(ttf.getBestCmap()) != 220:
        raise RuntimeError("Unexpected glyph inventory")
    checks.append("220 glyphs / 220 encoded codepoints")

    if not (
        table_digest(ttf, "GPOS")
        == table_digest(otf, "GPOS")
        == table_digest(web, "GPOS")
    ):
        raise RuntimeError("GPOS parity failed")
    if not (ttf.getBestCmap() == otf.getBestCmap() == web.getBestCmap()):
        raise RuntimeError("cmap parity failed")
    checks.append("TTF/OTF/WOFF2 cmap and GPOS parity")

    alpha_face = face(ALPHA2_TTF, 1000)
    rc_face = face(TTF, 1000)
    expected = {"я“": 0, "ї“": 0, "аї": 8, "їн": 8, "її": 16}
    for pair, target in expected.items():
        old = pair_delta(alpha_face, pair)
        new = pair_delta(rc_face, pair)
        if abs(old - target) > 0.2 or abs(new - target) > 0.2:
            raise RuntimeError(f"Unexpected shaping for {pair}: {old} -> {new}")
    checks.append('Shaping frozen: я“/ї“ 0; аї/їн +8; її +16')

    width_cases = (
        "Україна",
        "український",
        "поїзд",
        "приїзд",
        "її",
        "„внутрішня“",
        "річка пам’ять літературний читання",
    )
    for text in width_cases:
        alpha_width = alpha_face.getlength(text, features=["kern", "mark"])
        rc_width = rc_face.getlength(text, features=["kern", "mark"])
        if abs(alpha_width - rc_width) > 0.01:
            raise RuntimeError(f"Text width changed for {text!r}")
    checks.append("Target and control text widths identical to field-tested alpha2")

    for candidate in (ttf, otf, web):
        values = {
            record.toUnicode()
            for record in candidate["name"].names
            if record.nameID in (1, 2, 3, 4, 5, 6, 16, 17)
        }
        required = {FAMILY, STYLE, FULL_NAME, PS_NAME, VERSION_TEXT, UNIQUE_ID}
        if not required.issubset(values):
            raise RuntimeError(f"Required rc1 identity missing: {required - values}")
        if any(not value.isascii() for value in values):
            raise RuntimeError("Non-Latin editor-facing name detected")
        if abs(candidate["head"].fontRevision - 0.907) > 0.0001:
            raise RuntimeError("fontRevision mismatch")
        authors = {
            record.toUnicode()
            for record in candidate["name"].names
            if record.nameID == 9
        }
        if authors != {AUTHOR}:
            raise RuntimeError(f"Author metadata mismatch: {authors}")
    checks.append("Latin editor identity Ltava / Ltava Regular / Ltava-Regular; rc1 version recorded")
    checks.append("Author metadata: Олександр Гаврик")

    for font in (alpha_ttf, alpha_otf, alpha_web, ttf, otf, web):
        font.close()
    return checks


def wrap(draw: ImageDraw.ImageDraw, text: str, font, width: int) -> list[str]:
    lines: list[str] = []
    current = ""
    for word in text.split():
        candidate = word if not current else f"{current} {word}"
        if draw.textlength(candidate, font=font, features=["kern", "mark"]) <= width:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_text_block(draw, x, y, path, text, size, width, leading=1.45):
    font = face(path, size)
    for line in wrap(draw, text, font, width):
        draw.text((x, y), line, font=font, fill=INK, features=["kern", "mark"])
        y += round(size * leading)
    return y


def make_regression_proof() -> None:
    image = Image.new("RGB", (2000, 1500), PAPER)
    draw = ImageDraw.Draw(image)
    draw.text((70, 48), "LTAVA 0.9.7-rc1 — РЕГРЕСІЙНА ПРОБА", font=face(UI_BOLD, 34), fill=INK)
    draw.text(
        (70, 98),
        "ліворуч — перевірена alpha2 · праворуч — rc1 · очікувана різниця малюнка: відсутня",
        font=face(UI, 17),
        fill=MUTED,
    )
    draw.line((1000, 145, 1000, 1415), fill=RULE, width=2)
    for x, label, color in ((70, "0.9.7-alpha2", BLUE), (1045, "0.9.7-rc1", GREEN)):
        draw.text((x, 170), label, font=face(UI_BOLD, 18), fill=color)

    text = (
        "Україна читає уважно. Її літературний голос не поспішає: поїзд прибув, "
        "український текст зберіг рівний рух, а „Лтава“ лишила достатньо повітря "
        "навколо малої ї без розриву читацького ритму."
    )
    y = 220
    for size in (14, 16, 20, 32):
        draw.line((70, y, 1930, y), fill=RULE, width=1)
        draw.text((70, y + 16), f"{size} px", font=face(UI_BOLD, 13), fill=MUTED)
        draw_text_block(draw, 145, y + 14, ALPHA2_TTF, text, size, 760)
        draw_text_block(draw, 1075, y + 14, TTF, text, size, 760)
        y += {14: 190, 16: 205, 20: 235, 32: 315}[size]

    draw.line((70, 1170, 1930, 1170), fill=RULE, width=1)
    draw.text((70, 1192), "ЦІЛЬОВІ ПОСЛІДОВНОСТІ", font=face(UI_BOLD, 13), fill=MUTED)
    targets = "аї · ої · иї · уї · її · Україна · український · поїзд · приїзд · „внутрішня“"
    draw_text_block(draw, 70, 1235, ALPHA2_TTF, targets, 34, 850)
    draw_text_block(draw, 1045, 1235, TTF, targets, 34, 850)

    draw.rounded_rectangle((70, 1390, 1930, 1460), radius=12, fill=INK)
    draw.text(
        (96, 1413),
        "rc1: 220 гліфів · контури й метрики alpha2 заморожено · ї: +8 з кожного боку · її: +16",
        font=face(UI, 16),
        fill=PAPER,
    )
    image.save(PROOF)


def write_reports(checks: list[str]) -> None:
    VALIDATION.write_text(
        "LTAVA 0.9.7-rc1 — ПЕРВИННА ТЕХНІЧНА ПЕРЕВІРКА\n"
        "================================================\n\n"
        + "\n".join(f"PASS — {item}" for item in checks)
        + "\n",
        encoding="utf-8",
    )
    REPORT.write_text(
        """LTAVA 0.9.7-rc1 — ЗВІТ ПРО ФІКСАЦІЮ КАНДИДАТА
==================================================

Статус: перший реліз-кандидат 0.9.7.

Автор шрифту: Олександр Гаврик.

ПІДСТАВА
--------

Фінальний читальний протокол alpha2 позначає 8,5; 10,5; 12 і 14 pt як
стабільні у Word, LibreOffice, браузері та друці 100%. Обране рішення:
«перейти до 0.9.7-rc1».

ЗАФІКСОВАНО БЕЗ ЗМІН
--------------------

- 220 контурів і 220 закодованих позицій;
- номінальні ширини та бокові поля;
- cmap, GPOS, GSUB і GDEF;
- завершальна U+201C без експериментального коригування;
- контекстне повітря навколо малої ї: +8 з кожного letter-facing боку,
  +16 для пари її;
- латинські назви у меню: Ltava, Ltava Regular, Ltava-Regular.

ЗМІНЕНО
-------

Лише версійну ідентифікацію alpha2 → rc1 у name table та пов'язаних
метаданих. Числова версія лишається 0.907.

НАСТУПНИЙ ШЛЮЗ
---------------

Регресійно встановити rc1 замість alpha2, перевірити відкриття наявних
документів, відображення меню та експорт/друк. Будь-яку зміну контурів або
ритму після цього вважати окремим виправленням, а не частиною фіксації rc1.
""",
        encoding="utf-8",
    )


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    build_font(ALPHA2_TTF, TTF)
    build_font(ALPHA2_OTF, OTF)
    build_woff2()
    checks = validate_freeze()
    make_regression_proof()
    write_reports(checks)
    for path in (TTF, OTF, WOFF2, PROOF, VALIDATION, REPORT):
        print(path)


if __name__ == "__main__":
    main()
