import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const sourceDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(sourceDir);
const templatePath = path.join(sourceDir, 'Ltava-0.9.7-rc1-browser-template.html');
const fontPath = path.join(root, 'output', 'Ltava-0.9.7-rc1.woff2');
const outputPath = path.join(root, 'output', 'Ltava-0.9.7-rc1-browser-test.html');

const template = fs.readFileSync(templatePath, 'utf8');
const encodedFont = fs.readFileSync(fontPath).toString('base64');
const externalSource = "src:url('Ltava-0.9.7-rc1.woff2') format('woff2')";
const embeddedSource = `src:url('data:font/woff2;base64,${encodedFont}') format('woff2')`;

if (!template.includes(externalSource)) {
  throw new Error('Browser template does not contain the expected external WOFF2 source');
}

const output = template.replace(externalSource, embeddedSource);
if (output.includes(externalSource) || !output.includes('data:font/woff2;base64,')) {
  throw new Error('WOFF2 embedding failed');
}

fs.writeFileSync(outputPath, output, 'utf8');
console.log(outputPath);
