## FontBakery report

fontbakery version: 1.1.0







## Check results



<details><summary>[1] Ltava-0.9.7.ttf</summary>
<div>
<details>
    <summary>⚠️ <b>WARN</b> Check if each glyph has the recommended amount of contours. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#contour-count">contour_count</a></summary>
    <div>


> 
> Visually QAing thousands of glyphs by hand is tiring. Most glyphs can only
> be constructured in a handful of ways. This means a glyph's contour count
> will only differ slightly amongst different fonts, e.g a 'g' could either
> be 2 or 3 contours, depending on whether its double story or single story.
> 
> However, a quotedbl should have 2 contours, unless the font belongs
> to a display family.
> 
> This check currently does not cover variable fonts because there's plenty
> of alternative ways of constructing glyphs with multiple outlines for each
> feature in a VarFont. The expected contour count data for this check is
> currently optimized for the typical construction of glyphs in static fonts.
> 




> Original proposal: https://github.com/fonttools/fontbakery/issues/4829





* ⚠️ **WARN** <p>This check inspects the glyph outlines and detects the total number of contours in each of them. The expected values are infered from the typical ammounts of contours observed in a large collection of reference font families. The divergences listed below may simply indicate a significantly different design on some of your glyphs. On the other hand, some of these may flag actual bugs in the font such as glyphs mapped to an incorrect codepoint. Please consider reviewing the design and codepoint assignment of these to make sure they are correct.</p>
<p>The following glyphs do not have the recommended number of contours:</p>
<pre><code>- Glyph name: at	Contours detected: 3	Expected: 2

- Glyph name: guillemotleft	Contours detected: 1	Expected: 2

- Glyph name: guillemotright	Contours detected: 1	Expected: 2

- Glyph name: acutecomb	Contours detected: 2	Expected: 1

- Glyph name: uni0404	Contours detected: 2	Expected: 1

- Glyph name: uni0411	Contours detected: 3	Expected: 2

- Glyph name: uni041A	Contours detected: 2	Expected: 1

- Glyph name: uni0438	Contours detected: 2	Expected: 1

- Glyph name: uni0439	Contours detected: 3	Expected: 2

- Glyph name: uni0446	Contours detected: 2	Expected: 1

- 15 more.
</code></pre>
<p>Use -F or --full-lists to disable shortening of long lists.</p>
 [code: contour-count]



</div>
</details>
</div>
</details>




### Summary

| 💥 ERROR | ☠ FATAL | 🔥 FAIL | ⚠️ WARN | ⏩ SKIP | ℹ️ INFO | ✅ PASS | 🔎 DEBUG | 
| ---|---|---|---|---|---|---|---|
| 0 | 0 | 0 | 1 | 45 | 3 | 78 | 0 | 
| 0% | 0% | 0% | 1% | 35% | 2% | 61% | 0% | 



**Note:** The following loglevels were omitted in this report:


* SKIP
* INFO
* PASS
* DEBUG
