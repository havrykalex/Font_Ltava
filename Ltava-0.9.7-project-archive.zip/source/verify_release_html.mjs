import fs from 'node:fs';
import vm from 'node:vm';

const htmlPath = process.argv[2];
if (!htmlPath) throw new Error('Usage: node verify_release_html.mjs <html>');
const sourceHtml = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...sourceHtml.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
if (scripts.length !== 1) throw new Error(`Expected one inline script, found ${scripts.length}`);

class MockClassList {
  constructor() { this.values = new Set(); }
  toggle(value) { if (this.values.has(value)) this.values.delete(value); else this.values.add(value); }
  remove(value) { this.values.delete(value); }
  contains(value) { return this.values.has(value); }
}

class MockElement {
  constructor(id, value = '') {
    this.id = id;
    this.value = value;
    this.textContent = '';
    this.listeners = new Map();
    this.classList = new MockClassList();
  }
  addEventListener(type, callback) { this.listeners.set(type, callback); }
  fire(type) {
    const callback = this.listeners.get(type);
    if (!callback) throw new Error(`No ${type} listener on #${this.id}`);
    callback({ target: this });
  }
}

const elements = new Map();
for (const id of ['specimen', 'custom', 'size', 'lead', 'measure', 'sizeOut', 'leadOut',
  'measureOut', 'target', 'targetToggle', 'reset', 'fontStatus']) {
  elements.set(id, new MockElement(id));
}
elements.get('specimen').textContent = 'Початковий корпус: Україна, поїзд і її слово.';
elements.get('size').value = '10.5';
elements.get('lead').value = '1.45';
elements.get('measure').value = '68';
elements.get('sizeOut').textContent = '10,5 pt';
elements.get('leadOut').textContent = '1,45';
elements.get('measureOut').textContent = '68 ch';

const css = new Map();
const document = {
  documentElement: { style: { setProperty: (key, value) => css.set(key, value) } },
  getElementById(id) {
    const element = elements.get(id);
    if (!element) throw new Error(`Missing mock element #${id}`);
    return element;
  },
};
vm.runInNewContext(scripts[0][1], { document, window: { print() {} } }, { filename: htmlPath });

function check(condition, message) { if (!condition) throw new Error(message); }
const original = elements.get('specimen').textContent;
check(elements.get('fontStatus').textContent === 'Браузер не надає перевірку Font Loading API', 'Font status fallback mismatch');

const changes = {
  size: ['12', '--size', '12pt', '12 pt'],
  lead: ['1.55', '--leading', '1.55', '1,55'],
  measure: ['74', '--measure', '74ch', '74 ch'],
};
for (const [id, [value, property, expectedCss, expectedOutput]] of Object.entries(changes)) {
  elements.get(id).value = value;
  elements.get(id).fire('input');
  check(css.get(property) === expectedCss, `${id} CSS mismatch`);
  check(elements.get(`${id}Out`).textContent === expectedOutput, `${id} output mismatch`);
}

elements.get('custom').value = 'Власний текст: її країна і поїзд.';
elements.get('custom').fire('input');
check(elements.get('specimen').textContent === elements.get('custom').value, 'Custom text did not render');
elements.get('custom').value = '   ';
elements.get('custom').fire('input');
check(elements.get('specimen').textContent === original, 'Blank custom text did not restore corpus');

elements.get('targetToggle').fire('click');
check(elements.get('target').classList.contains('show'), 'Target panel did not open');
elements.get('reset').fire('click');
check(elements.get('size').value === '10.5', 'Size did not reset');
check(elements.get('lead').value === '1.45', 'Leading did not reset');
check(elements.get('measure').value === '68', 'Measure did not reset');
check(css.get('--size') === '10.5pt', 'Reset size CSS mismatch');
check(css.get('--leading') === '1.45', 'Reset leading CSS mismatch');
check(css.get('--measure') === '68ch', 'Reset measure CSS mismatch');
check(elements.get('specimen').textContent === original, 'Reset did not restore corpus');
check(!elements.get('target').classList.contains('show'), 'Reset did not close target panel');

console.log('PASS: 0.9.7 browser controls, custom text, target panel, and reset behavior');
