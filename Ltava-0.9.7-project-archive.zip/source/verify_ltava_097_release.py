#!/usr/bin/env python3
"""Independent release-gate checks for the final Ltava 0.9.7."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(PROJECT / "ltava_093/deps"))

from fontTools.pens.recordingPen import RecordingPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageStat


BASE = ROOT / "source/base"
ALPHA_TTF = BASE / "Ltava-0.9.7-alpha2.ttf"
ALPHA_OTF = BASE / "Ltava-0.9.7-alpha2.otf"
ALPHA_WOFF2 = BASE / "Ltava-0.9.7-alpha2.woff2"
TTF = ROOT / "output/Ltava-0.9.7.ttf"
OTF = ROOT / "output/Ltava-0.9.7.otf"
WOFF2 = ROOT / "output/Ltava-0.9.7.woff2"
PROOF = ROOT / "output/Ltava-0.9.7-regression-proof.png"
HTML = ROOT / "output/Ltava-0.9.7-browser-test.html"
FONTBAKERY = ROOT / "output/fontbakery/Ltava-0.9.7-fontbakery.json"
PROTOCOL = ROOT / "evidence/Ltava-0.9.7-alpha2-endurance-protocol-evaluated.txt"

VERSION_TEXT = "Version 0.907; Ltava 0.9.7"
UNIQUE_ID = "Ltava 0.9.7 Regular 2026"
AUTHOR = "Олександр Гаврик"
COPYRIGHT_EN = "Copyright © 2026 Олександр Гаврик. All rights reserved."
COPYRIGHT_UK = "© 2026 Олександр Гаврик. Усі права захищено."
RIGHTS_EN = (
    "Proprietary font software. All rights reserved. A limited, non-transferable "
    "permission is granted to download and install the font on one personally "
    "controlled device solely for non-commercial technical evaluation. Any other "
    "use, copying, modification, embedding, distribution, sublicensing, or sale "
    "requires the copyright holder's prior written permission."
)
RIGHTS_UK = (
    "Пропрієтарне програмне забезпечення шрифту. Усі права захищено. "
    "Надається обмежений і непередаваний дозвіл завантажити та встановити "
    "шрифт на одному особисто контрольованому пристрої виключно для "
    "некомерційного технічного ознайомлення. Будь-яке інше використання, "
    "копіювання, модифікація, вбудовування, поширення, субліцензування або "
    "продаж потребують попередньої письмової згоди правовласника."
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def glyph_digest(font: TTFont) -> str:
    digest = hashlib.sha256()
    glyph_set = font.getGlyphSet()
    for name in font.getGlyphOrder():
        pen = RecordingPen()
        glyph_set[name].draw(pen)
        digest.update(name.encode())
        digest.update(repr(pen.value).encode())
    return digest.hexdigest()


def table_digest(font: TTFont, tag: str) -> str:
    return hashlib.sha256(font.getTableData(tag)).hexdigest()


def face(path: Path, size: int = 1000):
    return ImageFont.truetype(str(path), size, layout_engine=ImageFont.Layout.RAQM)


def pair_delta(font, pair: str) -> float:
    return font.getlength(pair, features=["kern"]) - sum(
        font.getlength(character, features=["-kern"]) for character in pair
    )


def check_required_files() -> None:
    paths = [
        ALPHA_TTF,
        ALPHA_OTF,
        ALPHA_WOFF2,
        TTF,
        OTF,
        WOFF2,
        PROOF,
        HTML,
        FONTBAKERY,
        ROOT / "output/fontbakery/Ltava-0.9.7-fontbakery.md",
        ROOT / "output/Ltava-0.9.7-REPORT.txt",
        ROOT / "output/Ltava-0.9.7-VALIDATION.txt",
        PROTOCOL,
        ROOT / "evidence/Ltava-0.9.7-alpha2-endurance-QA.txt",
        ROOT / "Ltava-0.9.7-README.txt",
        ROOT / "Ltava-0.9.7-QA.txt",
        ROOT / "Ltava-0.9.7-RIGHTS.txt",
        ROOT / "Ltava-0.9.7-CHANGELOG.txt",
        ROOT / "Ltava-0.9.7-release-protocol.txt",
        ROOT / "source/build_ltava_097_release.py",
        ROOT / "source/embed_release_webfont.mjs",
        ROOT / "source/Ltava-0.9.7-browser-template.html",
        ROOT / "source/verify_release_html.mjs",
        ROOT / "source/verify_ltava_097_release.py",
        ROOT / "requirements.txt",
    ]
    missing = [
        str(path.relative_to(ROOT))
        for path in paths
        if not path.is_file() or path.stat().st_size == 0
    ]
    require(not missing, f"Missing or empty files: {missing}")


def check_field_protocol() -> None:
    text = PROTOCOL.read_text(encoding="utf-8")
    require(text.count("[х] стабільно") == 4, "Not all four tested sizes are stable")
    require(
        "[х] Word  [х] LibreOffice  [х] браузер  [х] друк 100%" in text,
        "Environment results are incomplete",
    )
    require("[х] перейти до 0.9.7-rc1" in text, "rc1 decision is not marked")
    for rejected in (
        "[х] зменшити +8 навколо малої ї",
        "[х] вилучити блок ї",
        "[х] повторити тест",
    ):
        require(rejected not in text, f"Conflicting protocol decision: {rejected}")


def check_frozen_tables(source: TTFont, candidate: TTFont, allowed: set[str], label: str) -> None:
    source_tags = {tag for tag in source.keys() if tag != "GlyphOrder"}
    candidate_tags = {tag for tag in candidate.keys() if tag != "GlyphOrder"}
    require(source_tags == candidate_tags, f"{label} table inventory changed")
    for tag in sorted(source_tags - allowed):
        require(table_digest(source, tag) == table_digest(candidate, tag), f"{label} {tag} changed")


def check_fonts() -> None:
    alpha_ttf, alpha_otf, alpha_web = TTFont(ALPHA_TTF), TTFont(ALPHA_OTF), TTFont(ALPHA_WOFF2)
    ttf, otf, web = TTFont(TTF), TTFont(OTF), TTFont(WOFF2)

    for source, candidate, label, allowed in (
        (alpha_ttf, ttf, "TTF", {"head", "name"}),
        (alpha_otf, otf, "OTF", {"CFF ", "head", "name"}),
        (alpha_web, web, "WOFF2", {"head", "name"}),
    ):
        require(source.getGlyphOrder() == candidate.getGlyphOrder(), f"{label} glyph order changed")
        require(glyph_digest(source) == glyph_digest(candidate), f"{label} outlines changed")
        require(source["hmtx"].metrics == candidate["hmtx"].metrics, f"{label} metrics changed")
        check_frozen_tables(source, candidate, allowed, label)

    require(len(ttf.getGlyphOrder()) == 220, "Glyph count mismatch")
    require(len(ttf.getBestCmap()) == 220, "Encoded codepoint count mismatch")
    require(ttf.getBestCmap() == otf.getBestCmap() == web.getBestCmap(), "Format cmap mismatch")
    require(
        table_digest(ttf, "GPOS") == table_digest(otf, "GPOS") == table_digest(web, "GPOS"),
        "Format GPOS mismatch",
    )

    expected_names = {
        1: "Ltava",
        2: "Regular",
        3: UNIQUE_ID,
        4: "Ltava Regular",
        5: VERSION_TEXT,
        6: "Ltava-Regular",
        16: "Ltava",
        17: "Regular",
    }
    for candidate, label in ((ttf, "TTF"), (otf, "OTF"), (web, "WOFF2")):
        for name_id, expected in expected_names.items():
            values = {
                record.toUnicode()
                for record in candidate["name"].names
                if record.nameID == name_id
            }
            require(values == {expected}, f"{label} nameID {name_id}: {values}")
            require(all(value.isascii() for value in values), f"{label} non-Latin editor name")
        all_names = {record.toUnicode() for record in candidate["name"].names}
        require(not any("alpha2" in value for value in all_names), f"{label} retains alpha2 identity")
        require(not any("0.9.7-rc1" in value for value in all_names), f"{label} retains rc1 identity")
        require(abs(candidate["head"].fontRevision - 0.907) < 0.0001, f"{label} fontRevision mismatch")
        authors = {
            record.toUnicode()
            for record in candidate["name"].names
            if record.nameID == 9
        }
        require(authors == {AUTHOR}, f"{label} author metadata mismatch: {authors}")
        manufacturers = {
            record.toUnicode()
            for record in candidate["name"].names
            if record.nameID == 8
        }
        require(manufacturers == {AUTHOR}, f"{label} manufacturer metadata mismatch: {manufacturers}")
        copyrights = {
            record.toUnicode()
            for record in candidate["name"].names
            if record.nameID == 0
        }
        require(
            copyrights == {COPYRIGHT_EN, COPYRIGHT_UK},
            f"{label} copyright metadata mismatch: {copyrights}",
        )
        rights = {
            record.toUnicode()
            for record in candidate["name"].names
            if record.nameID == 13
        }
        require(rights == {RIGHTS_EN, RIGHTS_UK}, f"{label} rights metadata mismatch: {rights}")
        require(
            not any(
                "prototype" in value.lower() or "прототип" in value.lower()
                for value in all_names
            ),
            f"{label} retains prototype metadata",
        )

    cff = otf["CFF "].cff
    top = cff.topDictIndex[0]
    require(cff.fontNames == ["Ltava-Regular"], "OTF CFF PostScript name mismatch")
    require(top.FullName == "Ltava Regular", "OTF CFF full name mismatch")
    require(top.FamilyName == "Ltava", "OTF CFF family name mismatch")
    require(top.version == "0.907", "OTF CFF version mismatch")
    require(
        top.Notice == "Copyright 2026 Oleksandr Havryk. All rights reserved.",
        "OTF CFF rights notice mismatch",
    )

    alpha_face, rc_face = face(ALPHA_TTF), face(TTF)
    expected_pairs = {"я“": 0, "ї“": 0, "аї": 8, "їн": 8, "її": 16}
    for pair, expected in expected_pairs.items():
        values = (pair_delta(alpha_face, pair), pair_delta(rc_face, pair))
        require(all(abs(value - expected) <= 0.2 for value in values), f"Shaping mismatch {pair}: {values}")

    for font in (alpha_ttf, alpha_otf, alpha_web, ttf, otf, web):
        font.close()


def render_line(path: Path, text: str, size: int) -> Image.Image:
    image = Image.new("L", (2200, 260), 255)
    draw = ImageDraw.Draw(image)
    draw.text((30, 40), text, font=face(path, size), fill=0, features=["kern", "mark"])
    return image


def check_raster_equivalence() -> None:
    samples = (
        "Україна · український · поїзд · приїзд · її слово",
        "аї ої иї уї її · „внутрішня“ · річка пам’ять",
    )
    for size in (14, 16, 20, 32, 48):
        for text in samples:
            alpha = render_line(ALPHA_TTF, text, size)
            rc = render_line(TTF, text, size)
            difference = ImageChops.difference(alpha, rc)
            require(difference.getbbox() is None, f"Raster regression at {size}px: {text}")
            alpha.close()
            rc.close()
            difference.close()


def check_proof() -> None:
    with Image.open(PROOF) as source:
        source.load()
        require(source.size == (2000, 1500), "Regression proof geometry mismatch")
        grayscale = source.convert("L")
        extrema = grayscale.getextrema()
        deviation = ImageStat.Stat(grayscale).stddev[0]
        grayscale.close()
    require(extrema[0] < 60 and extrema[1] > 235 and deviation > 10, "Regression proof appears blank")


def check_fontbakery() -> None:
    data = json.loads(FONTBAKERY.read_text(encoding="utf-8"))
    totals = data["result"]
    for severity in ("ERROR", "FATAL", "FAIL"):
        require(totals.get(severity, 0) == 0, f"FontBakery {severity}: {totals.get(severity, 0)}")
    require(totals.get("PASS", 0) == 78, "Unexpected FontBakery PASS count")
    require(totals.get("WARN", 0) == 1, "Unexpected FontBakery WARN count")
    require(totals.get("INFO", 0) == 3 and totals.get("SKIP", 0) == 45, "FontBakery totals changed")


def check_rights_documents() -> None:
    rights = (ROOT / "Ltava-0.9.7-RIGHTS.txt").read_text(encoding="utf-8")
    readme = (ROOT / "Ltava-0.9.7-README.txt").read_text(encoding="utf-8")
    changelog = (ROOT / "Ltava-0.9.7-CHANGELOG.txt").read_text(encoding="utf-8")
    normalized_rights = " ".join(rights.split())
    for text, label in ((rights, "rights"), (readme, "README")):
        require("© 2026 Олександр Гаврик. Усі права захищено." in text, f"{label} copyright missing")
        require("OFL" not in text, f"{label} contains conflicting OFL reference")
    require("некомерційного технічного ознайомлення" in normalized_rights, "Evaluation permission missing")
    require("попередньої письмової згоди" in normalized_rights, "Written-permission restriction missing")
    require("0.9.7 — 2026-08-02" in changelog, "Final changelog entry missing")


def check_html() -> None:
    source = HTML.read_text(encoding="utf-8")
    require('<html lang="uk">' in source, "HTML language is not Ukrainian")
    require(source.count("@font-face") == 1, "HTML must contain one font-face")
    embedded = re.search(r"data:font/woff2;base64,([A-Za-z0-9+/=]+)", source)
    require(embedded is not None, "HTML does not embed final WOFF2")
    embedded_bytes = base64.b64decode(embedded.group(1), validate=True)
    require(embedded_bytes == WOFF2.read_bytes(), "Embedded HTML webfont differs from final WOFF2")
    require("Ltava-0.9.7-alpha2.woff2" not in source, "HTML retains alpha2 webfont reference")
    require("Ltava 0.9.7" in source, "HTML final release identity missing")
    require("0.9.7-rc1" not in source, "HTML retains rc1 identity")
    require("© 2026 Олександр Гаврик. Усі права захищено." in source, "HTML rights notice missing")
    for element_id in ("specimen", "custom", "size", "lead", "measure", "target", "targetToggle", "reset", "fontStatus"):
        require(source.count(f'id="{element_id}"') == 1, f"HTML #{element_id} missing or duplicated")
    require(not re.search(r"(?:src|href)=[\"']https?://", source, flags=re.I), "HTML contains remote dependency")
    node = os.environ.get("CODEX_PRIMARY_RUNTIME_NODE", "node")
    result = subprocess.run(
        [node, str(ROOT / "source/verify_release_html.mjs"), str(HTML)],
        capture_output=True,
        text=True,
        check=True,
    )
    require(result.stdout.startswith("PASS:"), "HTML behavior verifier failed")


def main() -> None:
    checks = [
        ("required final release files", check_required_files),
        ("field-test decision", check_field_protocol),
        ("frozen outlines, metrics, OpenType tables and Latin identity", check_fonts),
        ("pixel-identical alpha2/0.9.7 raster output", check_raster_equivalence),
        ("regression proof geometry and content", check_proof),
        ("FontBakery release gate", check_fontbakery),
        ("proprietary rights documents", check_rights_documents),
        ("autonomous 0.9.7 browser regression test", check_html),
    ]
    for label, check in checks:
        check()
        print(f"PASS: {label}")
    print("PASS: Ltava 0.9.7 final release")


if __name__ == "__main__":
    main()
